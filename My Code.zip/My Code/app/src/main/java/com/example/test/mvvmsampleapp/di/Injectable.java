package com.example.test.mvvmsampleapp.di;

/**
 * Marker interface for fragments.
 */
public interface Injectable {
}
